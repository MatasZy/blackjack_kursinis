import java.util.ArrayList;
import java.util.Collections;

class Deck {
    private final ArrayList<Card> deck;

    public Deck() {
        deck = new ArrayList<>();
        String[] suits = {"Diamonds", "Hearts", "Clubs", "Spades"};
        for (int i = 2; i <= 10; i++) {
            for (String suit : suits) {
                deck.add(new Card(i, suit));
            }
        }
        for (String suit : suits) {
            deck.add(new Card(11, suit));
            deck.add(new Card(10, suit));
            deck.add(new Card(10, suit));
            deck.add(new Card(10, suit));
        }

        Collections.shuffle(deck);
    }

    public Card drawCard() {
        return deck.remove(deck.size() - 1);
    }





}