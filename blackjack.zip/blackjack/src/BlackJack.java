import java.util.Scanner;

class Blackjack {
    private final Deck deck;

    public Blackjack() {
        deck = new Deck();
    }

    public void play() {
        int playerCard1 = deck.drawCard().getValue();
        int playerCard2 = deck.drawCard().getValue();
        int playerTotal = playerCard1 + playerCard2;

        System.out.println("You got " + cardValueToString(playerCard1) + " of " + deck.drawCard().getSuit() + " and " + cardValueToString(playerCard2) + " of " + deck.drawCard().getSuit() + ".");
        System.out.println("Your total is " + playerTotal + ".");

        int dealerCard1 = deck.drawCard().getValue();
        int dealerCard2 = deck.drawCard().getValue();
        int dealerTotal = dealerCard1 + dealerCard2;

        System.out.println("Dealer got " + cardValueToString(dealerCard1) + " of " + deck.drawCard().getSuit() + " and " + cardValueToString(dealerCard2) + " of " + deck.drawCard().getSuit() + ".");
        System.out.println("Dealer's total is " + dealerTotal + ".");

        Scanner input = new Scanner(System.in);
        String command;
        while (playerTotal < 21) {
            System.out.println("Do you want to hit or stand? (H or S)");
            command = input.next();
            switch (command.toUpperCase()) {
                case "H":
                    int playerCard = deck.drawCard().getValue();
                    if (playerCard == 11 && playerTotal + playerCard > 21) {
                        playerTotal += 1;
                    } else {
                        playerTotal += playerCard;
                    }
                    System.out.println("You got " + cardValueToString(playerCard) + " of " + deck.drawCard().getSuit() + ".");
                    System.out.println("Your total is now " + playerTotal + ".");
                    if (playerTotal > 21) {
                        System.out.println("You busted with a total of " + playerTotal + ".");
                        return;
                    }
                    break;
                case "S":
                    break;
                default:
                    System.out.println("Invalid input. Please enter H or S.");
                    break;
            }
            if (command.equalsIgnoreCase("S")) {
                break;
            }
        }
        System.out.println("You stand with a total of " + playerTotal + ".");

        while (dealerTotal < 17) {
            int dealerCard = deck.drawCard().getValue();
            if (dealerCard == 11 && dealerTotal + dealerCard > 21) {
                dealerTotal += 1;
            } else {
                dealerTotal += dealerCard;
            }
            System.out.println("Dealer hits and got " + cardValueToString(dealerCard) + " of " + deck.drawCard().getSuit() + ".");
            System.out.println("Dealer's total is now " + dealerTotal + ".");
        }
        System.out.println("Dealer stands with a total of " + dealerTotal + ".");

        if (dealerTotal > 21) {
            System.out.println("Dealer busted with a total of " + dealerTotal + ".");
            System.out.println("You win!");
        } else if (playerTotal > dealerTotal) {
            System.out.println("Your total of " + playerTotal + " beats dealer's total of " + dealerTotal + ".");
            System.out.println("You win!");
        } else if (playerTotal == dealerTotal) {
            System.out.println("You and dealer have the same total of " + playerTotal + ".");
            System.out.println("It's a tie!");
        } else {
            System.out.println("Dealer's total of " + dealerTotal + " beats your total of " + playerTotal + ".");
            System.out.println("You lose!");
        }


    }



    private String cardValueToString(int value) {


        return switch (value) {
            case 11 -> "Ace";
            case 10 -> "10";
            case 9 -> "9";
            case 8 -> "8";
            case 7 -> "7";
            case 6 -> "6";
            case 5 -> "5";
            case 4 -> "4";
            case 3 -> "3";
            case 2 -> "2";
            default -> "Invalid";
        };
    }


}