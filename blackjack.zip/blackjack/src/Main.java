import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        boolean game=true;
        Scanner input= new Scanner(System.in);
        String command;
        Blackjack blackjack = new Blackjack();
        while(game){
            System.out.println("Do you want to play? (Y or N)");
            command=input.next();
            switch (command.toUpperCase()) {
                case "Y" -> blackjack.play();
                case "N" -> {
                    System.out.println("Quitting the game...");
                    game = false;
                }
                default -> System.out.println("Invalid command");
            }

        }

    }
}